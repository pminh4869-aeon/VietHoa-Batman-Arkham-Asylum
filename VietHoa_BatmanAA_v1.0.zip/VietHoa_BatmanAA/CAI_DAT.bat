@echo off
setlocal EnableExtensions
title Viet hoa Batman: Arkham Asylum GOTY - Cai dat
cd /d "%~dp0"
set "PK=%~dp0"
set "GAME=%~dp0.."
for %%I in ("%GAME%") do set "GAME=%%~fI"
set "BK=%GAME%\VietHoa_Backup"
set "XD=%PK%tools\xdelta3.exe"

echo ============================================================
echo   VIET HOA BATMAN: ARKHAM ASYLUM GOTY EDITION
echo ============================================================
echo.
if not exist "%GAME%\BmGame\CookedPC\BmGame.u" (
  echo [LOI] Khong tim thay game o thu muc:
  echo       %GAME%
  echo.
  echo Hay chep ca thu muc VietHoa_BatmanAA vao BEN TRONG thu muc game
  echo ^(thu muc co chua BmGame va Binaries^), roi chay lai file nay.
  echo.
  pause
  exit /b 1
)
if not exist "%XD%" (
  echo [LOI] Thieu file tools\xdelta3.exe. Hay giai nen lai day du goi Viet hoa.
  pause
  exit /b 1
)

echo Thu muc game: %GAME%
echo Ban goc se duoc sao luu vao: %BK%
echo.
echo Hay TAT GAME truoc khi cai. Nhan phim bat ky de bat dau...
pause >nul
echo.
echo Dang cai dat, vui long doi (khoang 1-3 phut)...

set /a OK=0
set /a FAIL=0
set /a MISS=0
for /f "usebackq eol=# delims=" %%F in ("%PK%danhsach.txt") do call :patch "%%F"

rem ---- file van ban (.int) ----
if not exist "%BK%\BmGame\Localization\INT\Frontend.int" (
  xcopy /e /i /y /q "%GAME%\BmGame\Localization\INT" "%BK%\BmGame\Localization\INT\" >nul
)
xcopy /y /r /q "%PK%files\BmGame\Localization\INT\*.int" "%GAME%\BmGame\Localization\INT\" >nul

echo.
echo ============================================================
echo   Da cai: %OK% file    Loi: %FAIL% file    Khong co trong game: %MISS% file
echo ============================================================
if %FAIL% GTR 0 (
  echo.
  echo Mot so file khong khop phien ban. Goi nay danh cho ban Steam GOTY.
  echo Hay vao Steam ^> chuot phai game ^> Properties ^> Installed Files ^>
  echo "Verify integrity of game files", XOA thu muc VietHoa_Backup, roi cai lai.
) else (
  echo.
  echo CAI DAT THANH CONG! Vao game, bat Subtitles trong Options de xem phu de.
)
echo.
pause
exit /b 0

:patch
set "REL=%~1"
set "SRC=%GAME%\%REL%"
set "ORIG=%BK%\%REL%"
set "NEWBK=0"
if not exist "%SRC%" (
  if not exist "%ORIG%" (
    set /a MISS+=1
    goto :eof
  )
)
if not exist "%ORIG%" (
  for %%D in ("%ORIG%") do if not exist "%%~dpD" mkdir "%%~dpD"
  copy /y "%SRC%" "%ORIG%" >nul
  set "NEWBK=1"
)
"%XD%" -d -f -s "%ORIG%" "%PK%patches\%REL%.xdelta" "%SRC%.vhtmp" >nul 2>&1
if errorlevel 1 goto :patchfail
if exist "%SRC%" attrib -r "%SRC%" >nul 2>&1
move /y "%SRC%.vhtmp" "%SRC%" >nul
if errorlevel 1 goto :patchfail
set /a OK+=1
goto :eof
:patchfail
echo   [LOI] %REL%
set /a FAIL+=1
if exist "%SRC%.vhtmp" del /q "%SRC%.vhtmp"
if "%NEWBK%"=="1" del /q "%ORIG%"
goto :eof
