@echo off
setlocal EnableExtensions
title Viet hoa Batman: Arkham Asylum GOTY - Go cai dat
set "GAME=%~dp0.."
for %%I in ("%GAME%") do set "GAME=%%~fI"
set "BK=%GAME%\VietHoa_Backup"
if not exist "%BK%\BmGame" (
  echo Khong tim thay ban sao luu: %BK%
  echo Ban co the khoi phuc bang Steam: chuot phai game ^> Properties ^> Installed Files ^>
  echo "Verify integrity of game files".
  pause
  exit /b 1
)
echo Se khoi phuc ban tieng Anh goc tu: %BK%
echo Hay TAT GAME truoc. Nhan phim bat ky de tiep tuc...
pause >nul
xcopy /e /y /r /q "%BK%\*" "%GAME%\" >nul
if errorlevel 1 (
  echo [LOI] Khong chep lai duoc. Thu chay file nay bang quyen Administrator.
  pause
  exit /b 1
)
echo Da khoi phuc ban goc. Ban co the xoa thu muc VietHoa_Backup neu muon.
pause
